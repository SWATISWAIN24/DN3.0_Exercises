package algorithms_datastructure;

import java.util.*;

interface Stock {
    void registerObserver(Observer observer);
    void deregisterObserver(Observer observer);
    void notifyObservers(String stockSymbol, double price);
}

class StockMarket implements Stock {
    private List<Observer> observers;
    private Map<String, Double> stockPrices;

    public StockMarket() {
        observers = new ArrayList<>();
        stockPrices = new HashMap<>();
    }

   
    public void registerObserver(Observer observer) {
        if (observer != null) {
            observers.add(observer);
        }
    }

    public void deregisterObserver(Observer observer) {
        if (observer != null) {
            observers.remove(observer);
        }
    }

    public void notifyObservers(String stockSymbol, double price) {
        Iterator<Observer> iterator = observers.iterator();
        while (iterator.hasNext()) {
            Observer observer = iterator.next();
            observer.update(stockSymbol, price);
        }
    }

    public void setStockPrice(String stockSymbol, double price) {
        stockPrices.put(stockSymbol, price);
        notifyObservers(stockSymbol, price);
    }
}

interface Observer {
    void update(String stockSymbol, double price);
}

class MobileApp implements Observer {
    
    public void update(String stockSymbol, double price) {
        System.out.println("Mobile App: Stock " + stockSymbol + " price updated to $" + price);
    }
}

class WebApp implements Observer {
    
    public void update(String stockSymbol, double price) {
        System.out.println("Web App: Stock " + stockSymbol + " price updated to $" + price);
    }
}

public class ObserverPattern {
    public static void main(String[] args) {
        
        StockMarket stockMarket = new StockMarket();

        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        stockMarket.setStockPrice("AAPL", 150.0);
        stockMarket.setStockPrice("GOOG", 2500.0);

        stockMarket.deregisterObserver(mobileApp);

        stockMarket.setStockPrice("AAPL", 160.0);
        stockMarket.setStockPrice("GOOG", 2600.0);
    }
}