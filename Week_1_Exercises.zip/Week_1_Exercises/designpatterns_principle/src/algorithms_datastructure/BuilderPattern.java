package algorithms_datastructure;

public class BuilderPattern {
    private String cpu;
    private int ram;
    private int storage;
    private BuilderPattern(ComputerBuilder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
    }
    public String getCpu() {
        return cpu;
    }

    public int getRam() {
        return ram;
    }

    public int getStorage() {
        return storage;
    }

    public static class ComputerBuilder {
        private String cpu;
        private int ram;
        private int storage;
        public ComputerBuilder(String cpu) {
            this.cpu = cpu;
        }
        public ComputerBuilder ram(int ram) {
            this.ram = ram;
            return this;
        }
        public ComputerBuilder storage(int storage) {
            this.storage = storage;
            return this;
        }
        public BuilderPattern build() {
            return new BuilderPattern(this);
        }
    }

    public static void main(String[] args) {
        BuilderPattern computer1 = new BuilderPattern.ComputerBuilder("Intel i7")
               .ram(16)
               .storage(512)
               .build();

        System.out.println("Computer 1 Configuration:");
        System.out.println("CPU: " + computer1.getCpu());
        System.out.println("RAM: " + computer1.getRam() + "GB");
        System.out.println("Storage: " + computer1.getStorage() + "GB");
        BuilderPattern computer2 = new BuilderPattern.ComputerBuilder("AMD Ryzen 7")
               .ram(8)
               .storage(256)
               .build();

        System.out.println("\nComputer 2 Configuration:");
        System.out.println("CPU: " + computer2.getCpu());
        System.out.println("RAM: " + computer2.getRam() + "GB");
        System.out.println("Storage: " + computer2.getStorage() + "GB");
    }
}