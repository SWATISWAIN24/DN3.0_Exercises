import java.util.HashMap;
import java.util.Map;


class Product {
    int productId;
    String productName;
    int quantity;
    double price;

    public Product(int productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    
    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}


public class InventoryManagementSystem {
    private Map<Integer, Product> products;

    public InventoryManagementSystem() {
        products = new HashMap<>();
    }

    
    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    
    public void updateProduct(int productId, Product product) {
        if (products.containsKey(productId)) {
            products.put(productId, product);
        }
    }

    
    public void deleteProduct(int productId) {
        products.remove(productId);
    }

    
    public Product getProduct(int productId) {
        return products.get(productId);
    }

    public static void main(String[] args) {
        InventoryManagementSystem inventory = new InventoryManagementSystem();

        
        Product product1 = new Product(1, "Product 1", 100, 30);
        Product product2 = new Product(2, "Product 2", 125, 15);

        
        inventory.addProduct(product1);
        inventory.addProduct(product2);

       
        Product updatedProduct1 = new Product(1, "Updated Product 1", 15, 22.99);
        inventory.updateProduct(1, updatedProduct1);

        
        inventory.deleteProduct(2);

        
        Product retrievedProduct1 = inventory.getProduct(1);
        System.out.println("Product ID: " + retrievedProduct1.getProductId());
        System.out.println("Product Name: " + retrievedProduct1.getProductName());
        System.out.println("Quantity: " + retrievedProduct1.getQuantity());
        System.out.println("Price: " + retrievedProduct1.getPrice());
    }
}